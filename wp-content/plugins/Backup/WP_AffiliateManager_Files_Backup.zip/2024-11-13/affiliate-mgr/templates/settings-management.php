<?php
if (!defined('ABSPATH')) {
    exit;
}

// Get instance of SettingsManager
$settings_manager = new AffiliateManager_SettingsManager();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['affiliate_mgr_settings_nonce']) && wp_verify_nonce($_POST['affiliate_mgr_settings_nonce'], 'affiliate_mgr_settings')) {
    $not_found_url = isset($_POST['not_found_url']) ? sanitize_text_field($_POST['not_found_url']) : '';
    $not_found_page_local_or_remote = isset($_POST['not_found_page_local_or_remote']) ? sanitize_text_field($_POST['not_found_page_local_or_remote']) : '';
    $settings_manager->update_setting('offer_not_found_url', $not_found_url);
    $settings_manager->update_setting('not_found_page_local_or_remote', $not_found_page_local_or_remote);
    echo '<div class="updated"><p>Settings saved successfully.</p></div>';
}

// Get current settings values
$not_found_url = $settings_manager->get_setting('offer_not_found_url');
$not_found_page_local_or_remote = $settings_manager->get_setting('not_found_page_local_or_remote');
?>
<div class="wrap">
   <h1><?php esc_html_e('Affiliate Manager Settings', 'affiliate-mgr'); ?></h1>
   <p>Here you can manage all of the settings for the plugin</p>
   <form method="post" action="">
        <?php wp_nonce_field('affiliate_mgr_settings', 'affiliate_mgr_settings_nonce'); ?>

        <table class="form-table">
            <tr valign="top">
                <th scope="row"><?php esc_html_e('Offer Not Found Page Type', 'affiliate-mgr'); ?></th>
                <td>
                    <select name="not_found_page_local_or_remote" class="regular-text">
                        <option value="local" <?php selected($not_found_page_local_or_remote, 'local'); ?>><?php esc_html_e('Local', 'affiliate-mgr'); ?></option>
                        <option value="remote" <?php selected($not_found_page_local_or_remote, 'remote'); ?>><?php esc_html_e('Remote', 'affiliate-mgr'); ?></option>
                    </select>
                    <p class="description"><?php esc_html_e('Choose whether to use a local WordPress slug or a remote URL for the "Offer Not Found" page.', 'affiliate-mgr'); ?></p>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><?php esc_html_e('Offer Not Found URL', 'affiliate-mgr'); ?></th>
                <td>
                    <input type="text" name="not_found_url" value="<?php echo esc_attr($not_found_url); ?>" class="regular-text" />
                    <p class="description"><?php esc_html_e('URL to redirect to when an offer is not found.', 'affiliate-mgr'); ?></p>
                </td>
            </tr>
        </table>

        <?php submit_button(__('Save Settings', 'affiliate-mgr')); ?>
    </form>
</div>